#ifndef _UTIL_H_
#define _UTIL_H_

int handle_connection(void*);

#endif
